The "data" directory should include, at a minimum, the following files:
- ModKogDat.csv
- ModKogDat3F.csv
- ZA7558_v2-0-0.dta.zip
- ZA7558_v2-0-0.sav
